
function buildListTitleForm() {
	var node = document.createElement('form')
	node.innerHTML =
		'<div class="newitem-title-wrapper">' +
		'<input id="trello-list-title-input" type="text">' +
		'<input id="trello-list-title-submit" type="submit" value="Зберегти">' +
		'</div>'
	node.style.display = 'none'
	return node
}